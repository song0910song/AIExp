This archive contains dialux-task.json, manifest.json and final selected luminaire assets.
Source ZIP files are in photometry/; extracted IES/LDT/ULD files are in photometry/extracted/.
Every local asset is listed with its source and SHA-256 in the manifest.
